package com.geodriveai;

import java.nio.file.Path;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

  @Override
  public void addResourceHandlers(ResourceHandlerRegistry registry) {
    String videoLocation = Path.of("video").toAbsolutePath().toUri().toString();
    registry.addResourceHandler("/video-files/**")
        .addResourceLocations(videoLocation)
        .setCachePeriod(0);
  }
}
