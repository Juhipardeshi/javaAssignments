package com.geodriveai;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

public class DatasetLoader {

  enum SpeedUnit {
    KMH,
    MPS,
    UNKNOWN
  }

  private final List<Map<String, String>> rows = new ArrayList<>();
  private final List<String> headers = new ArrayList<>();
  private Path source;
  private int cursor = 0;
  private String latKey;
  private String lonKey;
  private String speedKey;
  private String timeKey;
  private String rpmKey;
  private String fuelKey;
  private String kplKey;
  private SpeedUnit speedUnit = SpeedUnit.UNKNOWN;

  DatasetLoader(Path path) throws IOException {
    load(path);
  }

  public synchronized void reload(Path path) throws IOException {
    load(path);
  }

  public synchronized Map<String, String> next() {
    if (rows.isEmpty()) {
      return Map.of();
    }
    if (cursor >= rows.size()) {
      cursor = 0;
    }
    return rows.get(cursor++);
  }

  public synchronized int totalRows() {
    return rows.size();
  }

  public synchronized int currentIndex() {
    if (rows.isEmpty()) {
      return 0;
    }
    return Math.min(cursor, rows.size() - 1);
  }

  public synchronized void seekToIndex(int index) {
    if (rows.isEmpty()) {
      cursor = 0;
      return;
    }
    cursor = Math.max(0, Math.min(index, rows.size() - 1));
  }

  public synchronized String getLatKey() {
    return latKey;
  }

  public synchronized String getLonKey() {
    return lonKey;
  }

  public synchronized String getSpeedKey() {
    return speedKey;
  }

  public synchronized String getRpmKey() {
    return rpmKey;
  }

  public synchronized String getTimeKey() {
    return timeKey;
  }

  public synchronized String getFuelKey() {
    return fuelKey;
  }

  public synchronized String getKplKey() {
    return kplKey;
  }

  public synchronized SpeedUnit getSpeedUnit() {
    return speedUnit;
  }

  public synchronized boolean hasRpm() {
    return rpmKey != null;
  }

  public synchronized boolean hasFuel() {
    return fuelKey != null;
  }

  public synchronized boolean hasKpl() {
    return kplKey != null;
  }

  public synchronized List<Map<String, String>> snapshotRows() {
    return rows.stream().map(HashMap::new).collect(Collectors.toList());
  }

  private void load(Path path) throws IOException {
    this.source = path;
    this.cursor = 0;
    this.rows.clear();
    this.headers.clear();
    this.latKey = null;
    this.lonKey = null;
    this.speedKey = null;
    this.timeKey = null;
    this.rpmKey = null;
    this.fuelKey = null;
    this.kplKey = null;
    this.speedUnit = SpeedUnit.UNKNOWN;

    List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
    if (lines.isEmpty()) {
      throw new IOException("Empty dataset");
    }
    String headerLine = lines.stream().filter(l -> !l.isBlank()).findFirst()
        .orElseThrow(() -> new IOException("Missing header row"));
    char delimiter = detectDelimiter(headerLine);
    List<String> parsedHeaders = parseLine(headerLine, delimiter);
    this.headers.addAll(parsedHeaders);
    detectColumns(parsedHeaders);

    for (String raw : lines) {
      if (raw.isBlank()) {
        continue;
      }
      if (raw.strip().equals(headerLine.strip())) {
        continue;
      }
      List<String> values = parseLine(raw, delimiter);
      Map<String, String> row = new HashMap<>();
      for (int i = 0; i < headers.size(); i++) {
        String header = headers.get(i);
        String value = i < values.size() ? values.get(i) : "";
        row.put(header, value);
      }
      rows.add(row);
    }
  }

  private char detectDelimiter(String headerLine) {
    int tabs = headerLine.length() - headerLine.replace("\t", "").length();
    int commas = headerLine.length() - headerLine.replace(",", "").length();
    if (tabs > commas) {
      return '\t';
    }
    return ',';
  }

  private List<String> parseLine(String line, char delimiter) {
    List<String> cells = new ArrayList<>();
    StringBuilder current = new StringBuilder();
    boolean inQuotes = false;
    for (int i = 0; i < line.length(); i++) {
      char c = line.charAt(i);
      if (c == '"') {
        inQuotes = !inQuotes;
        continue;
      }
      if (c == delimiter && !inQuotes) {
        cells.add(clean(current.toString()));
        current.setLength(0);
        continue;
      }
      current.append(c);
    }
    cells.add(clean(current.toString()));
    return cells;
  }

  private String clean(String value) {
    return value == null ? "" : value.trim();
  }

  private void detectColumns(List<String> parsedHeaders) {
    int bestLatScore = Integer.MIN_VALUE;
    int bestLonScore = Integer.MIN_VALUE;
    int bestSpeedScore = Integer.MIN_VALUE;
    int bestTimeScore = Integer.MIN_VALUE;
    int bestRpmScore = Integer.MIN_VALUE;
    int bestFuelScore = Integer.MIN_VALUE;
    int bestKplScore = Integer.MIN_VALUE;

    for (String header : parsedHeaders) {
      String normalized = normalize(header);

      int latScore = scoreLatitude(normalized);
      if (latScore > bestLatScore) {
        bestLatScore = latScore;
        latKey = latScore > 0 ? header : latKey;
      }

      int lonScore = scoreLongitude(normalized);
      if (lonScore > bestLonScore) {
        bestLonScore = lonScore;
        lonKey = lonScore > 0 ? header : lonKey;
      }

      int speedScore = scoreSpeed(normalized);
      if (speedScore > bestSpeedScore) {
        bestSpeedScore = speedScore;
        if (speedScore > 0) {
          speedKey = header;
          speedUnit = inferSpeedUnit(normalized);
        }
      }

      int timeScore = scoreTime(normalized);
      if (timeScore > bestTimeScore) {
        bestTimeScore = timeScore;
        timeKey = timeScore > 0 ? header : timeKey;
      }

      int rpmScore = normalized.contains("rpm") ? 10 : Integer.MIN_VALUE;
      if (rpmScore > bestRpmScore) {
        bestRpmScore = rpmScore;
        rpmKey = rpmScore > 0 ? header : rpmKey;
      }

      int fuelScore = scoreFuel(normalized);
      if (fuelScore > bestFuelScore) {
        bestFuelScore = fuelScore;
        fuelKey = fuelScore > 0 ? header : fuelKey;
      }

      int kplScore = scoreKpl(normalized);
      if (kplScore > bestKplScore) {
        bestKplScore = kplScore;
        kplKey = kplScore > 0 ? header : kplKey;
      }
    }

    if (speedUnit == SpeedUnit.UNKNOWN && speedKey != null) {
      speedUnit = inferSpeedUnit(normalize(speedKey));
    }
  }

  private String normalize(String header) {
    return header.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9/ ]+", " ").replaceAll("\\s+", " ").trim();
  }

  private int scoreLatitude(String normalized) {
    if (!(normalized.contains("latitude") || normalized.equals("lat") || normalized.startsWith("lat "))) {
      return Integer.MIN_VALUE;
    }
    int score = 10;
    if (normalized.contains("gps")) {
      score += 6;
    }
    if (normalized.contains("accuracy") || normalized.contains("sensor")) {
      score -= 8;
    }
    return score;
  }

  private int scoreLongitude(String normalized) {
    if (!(normalized.contains("longitude") || normalized.contains("lng") || normalized.equals("lon")
        || normalized.startsWith("lon "))) {
      return Integer.MIN_VALUE;
    }
    int score = 10;
    if (normalized.contains("gps")) {
      score += 6;
    }
    if (normalized.contains("accuracy") || normalized.contains("sensor")) {
      score -= 8;
    }
    return score;
  }

  private int scoreSpeed(String normalized) {
    if (!normalized.contains("speed")) {
      return Integer.MIN_VALUE;
    }
    int score = 10;
    if (normalized.contains("gps") || normalized.contains("obd")) {
      score += 12;
    }
    if (normalized.contains("km/h") || normalized.contains("kmh")) {
      score += 8;
    }
    if (normalized.contains("m/s") || normalized.contains("meters/second")) {
      score += 2;
    }
    if (normalized.contains("average") || normalized.contains("difference") || normalized.contains("trip")) {
      score -= 12;
    }
    return score;
  }

  private int scoreFuel(String normalized) {
    if (!(normalized.contains("fuel") || normalized.contains("consumption")
        || normalized.contains("liters") || normalized.contains("l/hr"))) {
      return Integer.MIN_VALUE;
    }
    int score = 10;
    if (normalized.contains("flow")) {
      score += 6;
    }
    if (normalized.contains("trip")) {
      score -= 4;
    }
    return score;
  }

  private int scoreTime(String normalized) {
    if (!normalized.contains("time")) {
      return Integer.MIN_VALUE;
    }
    int score = 10;
    if (normalized.contains("gps")) {
      score += 5;
    }
    if (normalized.contains("device")) {
      score += 3;
    }
    if (normalized.contains("trip")) {
      score -= 3;
    }
    return score;
  }

  private int scoreKpl(String normalized) {
    if (!(normalized.contains("kpl") || normalized.contains("kmpl") || normalized.contains("mileage")
        || normalized.contains("efficiency") || normalized.contains("mpg"))) {
      return Integer.MIN_VALUE;
    }
    int score = 10;
    if (normalized.contains("instant")) {
      score += 6;
    }
    if (normalized.contains("average") || normalized.contains("long term")) {
      score -= 2;
    }
    if (normalized.contains("trip average")) {
      score -= 1;
    }
    return score;
  }

  private SpeedUnit inferSpeedUnit(String normalized) {
    if (normalized.contains("m/s") || normalized.contains("meters/second")) {
      return SpeedUnit.MPS;
    }
    if (normalized.contains("km/h") || normalized.contains("kmh") || normalized.contains("kilometer")) {
      return SpeedUnit.KMH;
    }
    return SpeedUnit.UNKNOWN;
  }
}
