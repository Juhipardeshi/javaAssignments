package com.geodriveai;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.ResourceRegion;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRange;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api")
public class SimulationController {

  private final SimulationService simulationService;
  private final DatasetLoader datasetLoader;
  private final LocalMediaResolver mediaResolver;
  private final Logger log = LoggerFactory.getLogger(SimulationController.class);

  public SimulationController(SimulationService simulationService, DatasetLoader datasetLoader,
      LocalMediaResolver mediaResolver) {
    this.simulationService = simulationService;
    this.datasetLoader = datasetLoader;
    this.mediaResolver = mediaResolver;
  }

  @GetMapping("/simulate")
  public Map<String, Object> simulate() {
    return simulationService.nextFrame();
  }

  @GetMapping("/report")
  public Map<String, Object> report() {
    return simulationService.generateTripReport();
  }

  @GetMapping("/seek")
  public Map<String, Object> seek(@RequestParam("row") int row) {
    return simulationService.seekToRow(row);
  }

  @GetMapping("/media")
  public Map<String, Object> media() throws IOException {
    Map<String, Object> metadata = simulationService.timelineMetadata();
    List<Path> videoPaths = mediaResolver.resolveVideoPaths();
    Optional<Path> datasetPath = Optional.of(mediaResolver.resolveDatasetPath());

    metadata.put("videoAvailable", !videoPaths.isEmpty());
    metadata.put("videoFileName", videoPaths.isEmpty() ? null : videoPaths.get(0).getFileName().toString());
    metadata.put("videoUrl", videoPaths.isEmpty() ? null : videoUrl(videoPaths.get(0)));
    metadata.put("videos", buildVideoList(videoPaths));
    metadata.put("datasetFileName", datasetPath.map(path -> path.getFileName().toString()).orElse(null));
    metadata.put("videoSyncOffsetSeconds",
        videoPaths.isEmpty() ? 0
            : resolveVideoSyncOffsetSeconds(Optional.of(videoPaths.get(0)), metadata.get("datasetStartTimestamp")));
    return metadata;
  }

  @GetMapping("/video/{fileName:.+}")
  public ResponseEntity<?> video(@PathVariable String fileName,
      @RequestHeader HttpHeaders headers) throws IOException {
    Optional<Path> videoPath = mediaResolver.resolveVideoPaths().stream()
        .filter(path -> path.getFileName().toString().equals(fileName))
        .findFirst();
    if (videoPath.isEmpty()) {
      return ResponseEntity.notFound().build();
    }

    Path path = videoPath.get();
    Resource resource = new FileSystemResource(path);
    long contentLength = resource.contentLength();
    MediaType mediaType = resolveMediaType(path);

    if (!headers.getRange().isEmpty()) {
      HttpRange range = headers.getRange().get(0);
      ResourceRegion region = range.toResourceRegion(resource);
      return ResponseEntity.status(HttpStatus.PARTIAL_CONTENT)
          .contentType(mediaType)
          .header(HttpHeaders.ACCEPT_RANGES, "bytes")
          .body(region);
    }

    return ResponseEntity.ok()
        .contentLength(contentLength)
        .contentType(mediaType)
        .header(HttpHeaders.ACCEPT_RANGES, "bytes")
        .body(resource);
  }

  @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
  public ResponseEntity<Map<String, String>> upload(@RequestParam("file") MultipartFile file) {
    Path target = Path.of("dataset.csv");
    try {
      Files.copy(file.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);
      datasetLoader.reload(target);
      simulationService.reset();
      return ResponseEntity.ok(Map.of("message", "Dataset reloaded", "rows",
          String.valueOf(datasetLoader.totalRows())));
    } catch (IOException e) {
      log.error("Failed to reload dataset", e);
      return ResponseEntity.badRequest()
          .body(Map.of("message", "Upload failed: " + e.getMessage()));
    }
  }

  @PostMapping("/reload-local")
  public ResponseEntity<Map<String, String>> reloadLocal() {
    try {
      datasetLoader.reload(mediaResolver.resolveDatasetPath());
      simulationService.reset();
      return ResponseEntity.ok(Map.of("message", "Local dataset loaded", "rows",
          String.valueOf(datasetLoader.totalRows())));
    } catch (IOException e) {
      log.error("Failed to reload local dataset", e);
      return ResponseEntity.badRequest()
          .body(Map.of("message", "Reload failed: " + e.getMessage()));
    }
  }

  private double resolveVideoSyncOffsetSeconds(Optional<Path> videoPath, Object datasetStartTimestamp) {
    if (videoPath.isEmpty() || !(datasetStartTimestamp instanceof Long datasetStartMillis)) {
      return 0;
    }

    Optional<LocalDateTime> videoStart = mediaResolver.parseTimestampFromFileName(videoPath.get());
    if (videoStart.isEmpty()) {
      return 0;
    }

    long videoEpoch = videoStart.get().atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
    return Math.max(0, (datasetStartMillis - videoEpoch) / 1000.0);
  }

  private MediaType resolveMediaType(Path path) {
    String fileName = path.getFileName().toString().toLowerCase();
    if (fileName.endsWith(".mov")) {
      return MediaType.valueOf("video/quicktime");
    }
    if (fileName.endsWith(".webm")) {
      return MediaType.valueOf("video/webm");
    }
    if (fileName.endsWith(".m4v")) {
      return MediaType.valueOf("video/x-m4v");
    }
    return MediaType.valueOf("video/mp4");
  }

  private List<Map<String, Object>> buildVideoList(List<Path> videoPaths) {
    List<Map<String, Object>> videos = new ArrayList<>();
    for (Path path : videoPaths) {
      Map<String, Object> entry = new java.util.LinkedHashMap<>();
      entry.put("fileName", path.getFileName().toString());
      entry.put("url", videoUrl(path));
      entry.put("timestamp", mediaResolver.parseTimestampFromFileName(path)
          .map(value -> value.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli())
          .orElse(null));
      videos.add(entry);
    }
    return videos;
  }

  private String videoUrl(Path path) {
    return "/video-files/" + path.getFileName();
  }
}
