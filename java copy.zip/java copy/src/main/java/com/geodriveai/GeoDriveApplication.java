package com.geodriveai;

import java.io.IOException;
import java.nio.file.Path;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class GeoDriveApplication {

  public static void main(String[] args) {
    SpringApplication.run(GeoDriveApplication.class, args);
  }

  @Bean
  public DatasetLoader datasetLoader(LocalMediaResolver mediaResolver) throws IOException {
    Path datasetPath = mediaResolver.resolveDatasetPath();
    return new DatasetLoader(datasetPath);
  }
}
