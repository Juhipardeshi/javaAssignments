package com.geodriveai;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

@Component
public class LocalMediaResolver {

  private static final Path VIDEO_DIR = Path.of("video");
  private static final Path FALLBACK_DATASET = Path.of("src/main/resources/dataset.csv").toAbsolutePath();
  private static final Pattern TIMESTAMP_PATTERN =
      Pattern.compile("(\\d{4}-[A-Za-z]{3}-\\d{2}_\\d{2}-\\d{2}-\\d{2})");
  private static final DateTimeFormatter FILE_TIMESTAMP_FORMAT =
      DateTimeFormatter.ofPattern("yyyy-MMM-dd_HH-mm-ss", Locale.ENGLISH);

  public Path resolveDatasetPath() throws IOException {
    return findNewestByExtensions(List.of(".csv")).orElse(FALLBACK_DATASET);
  }

  public Optional<Path> resolveVideoPath() throws IOException {
    return findNewestByExtensions(List.of(".mp4", ".mov", ".m4v", ".webm"));
  }

  public List<Path> resolveVideoPaths() throws IOException {
    if (!Files.isDirectory(VIDEO_DIR)) {
      return List.of();
    }
    try (var paths = Files.list(VIDEO_DIR)) {
      Map<String, Path> preferredByStem = new HashMap<>();

      paths
          .filter(Files::isRegularFile)
          .filter(path -> hasExtension(path, List.of(".mp4", ".mov", ".m4v", ".webm")))
          .forEach(path -> preferredByStem.merge(
              stem(path),
              path,
              (existing, candidate) -> preferVideo(existing, candidate) ? existing : candidate));

      return preferredByStem.values().stream()
          .sorted(Comparator.comparing(path -> path.getFileName().toString().toLowerCase(Locale.ROOT)))
          .collect(java.util.stream.Collectors.toCollection(ArrayList::new));
    }
  }

  public Optional<LocalDateTime> parseTimestampFromFileName(Path path) {
    if (path == null) {
      return Optional.empty();
    }
    Matcher matcher = TIMESTAMP_PATTERN.matcher(path.getFileName().toString());
    if (!matcher.find()) {
      return Optional.empty();
    }
    try {
      return Optional.of(LocalDateTime.parse(matcher.group(1), FILE_TIMESTAMP_FORMAT));
    } catch (DateTimeParseException ex) {
      return Optional.empty();
    }
  }

  private Optional<Path> findNewestByExtensions(List<String> extensions) throws IOException {
    if (!Files.isDirectory(VIDEO_DIR)) {
      return Optional.empty();
    }
    try (var paths = Files.list(VIDEO_DIR)) {
      return paths
          .filter(Files::isRegularFile)
          .filter(path -> hasExtension(path, extensions))
          .max(Comparator.comparing(path -> path.getFileName().toString()));
    }
  }

  private boolean hasExtension(Path path, List<String> extensions) {
    String fileName = path.getFileName().toString().toLowerCase(Locale.ROOT);
    return extensions.stream().anyMatch(fileName::endsWith);
  }

  private boolean preferVideo(Path existing, Path candidate) {
    return extensionRank(existing) <= extensionRank(candidate);
  }

  private int extensionRank(Path path) {
    String fileName = path.getFileName().toString().toLowerCase(Locale.ROOT);
    if (fileName.endsWith(".mp4")) {
      return 0;
    }
    if (fileName.endsWith(".m4v")) {
      return 1;
    }
    if (fileName.endsWith(".webm")) {
      return 2;
    }
    if (fileName.endsWith(".mov")) {
      return 3;
    }
    return 10;
  }

  private String stem(Path path) {
    String fileName = path.getFileName().toString();
    int dotIndex = fileName.lastIndexOf('.');
    return dotIndex >= 0 ? fileName.substring(0, dotIndex).toLowerCase(Locale.ROOT) : fileName.toLowerCase(Locale.ROOT);
  }
}
