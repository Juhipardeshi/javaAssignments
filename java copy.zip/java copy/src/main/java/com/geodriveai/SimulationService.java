package com.geodriveai;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.springframework.stereotype.Service;

@Service
public class SimulationService {

  private final DatasetLoader loader;
  private final Lock lock = new ReentrantLock();
  private double avgSpeedSum;
  private double avgKplSum;
  private int kplSamples;
  private double maxSpeed;
  private int totalPoints;
  private double score = 72;
  private double previousSpeed;
  private double previousKpl = 15;
  private int smoothDrivingCount;
  private int frequentSpeedChangesCount;
  private int vehicleStoppedCount;
  private int highRpmCount;
  private int balancedThrottleCount;
  private int goodStatusCount;
  private int normalStatusCount;
  private int poorStatusCount;
  private int hardAccelerationCount;
  private int hardBrakingCount;

  public SimulationService(DatasetLoader loader) {
    this.loader = loader;
  }

  public void reset() {
    lock.lock();
    try {
      avgSpeedSum = 0;
      avgKplSum = 0;
      kplSamples = 0;
      maxSpeed = 0;
      totalPoints = 0;
      score = 72;
      previousSpeed = 0;
      previousKpl = 15;
      smoothDrivingCount = 0;
      frequentSpeedChangesCount = 0;
      vehicleStoppedCount = 0;
      highRpmCount = 0;
      balancedThrottleCount = 0;
      goodStatusCount = 0;
      normalStatusCount = 0;
      poorStatusCount = 0;
      hardAccelerationCount = 0;
      hardBrakingCount = 0;
    } finally {
      lock.unlock();
    }
  }

  public Map<String, Object> nextFrame() {
    lock.lock();
    try {
      Map<String, String> row = loader.next();
      if (row.isEmpty()) {
        return buildFallback();
      }
      double lat = safeParse(row.get(loader.getLatKey()), 18.52);
      double lon = safeParse(row.get(loader.getLonKey()), 73.85);
      double speed = convertSpeed(row.get(loader.getSpeedKey()));
      double rpm = safeParse(row.get(loader.getRpmKey()), 0);
      double fuel = safeParse(row.get(loader.getFuelKey()), 0);
      double kpl = safeParse(row.get(loader.getKplKey()), 0);
      int currentRow = (totalPoints % Math.max(1, loader.totalRows())) + 1;
      Instant frameTime = parseInstant(row.get(loader.getTimeKey()));
      Instant tripStart = resolveDatasetStartInstant();

      if (kpl <= 0) {
        kpl = estimateKpl(speed, rpm, fuel);
      }
      String status = classifyStatus(speed, rpm);
      double speedVariation = Math.abs(speed - previousSpeed);
      trackDrivingEvents(speed - previousSpeed);
      String insight = buildInsight(speed, rpm, status, speedVariation);
      trackInsight(insight, status);
      updateScore(status, speed, rpm, kpl, fuel, speedVariation);
      totalPoints++;
      avgSpeedSum += speed;
      maxSpeed = Math.max(maxSpeed, speed);
      avgKplSum += kpl;
      kplSamples++;
      previousSpeed = speed;
      previousKpl = kpl;

      Map<String, Object> payload = new LinkedHashMap<>();
      payload.put("lat", lat);
      payload.put("lon", lon);
      payload.put("speed", round(speed));
      payload.put("rpm", round(rpm));
      payload.put("kpl", round(kpl));
      payload.put("status", status);
      payload.put("score", round(score));
      payload.put("insight", insight);
      payload.put("avgSpeed", round(avgSpeedSum / totalPoints));
      payload.put("avgKpl", round(kplSamples == 0 ? 0 : avgKplSum / kplSamples));
      payload.put("maxSpeed", round(maxSpeed));
      payload.put("totalPoints", totalPoints);
      payload.put("rowNumber", currentRow);
      payload.put("rowCount", loader.totalRows());
      payload.put("frameTimestamp", frameTime != null ? frameTime.toEpochMilli() : null);
      payload.put("elapsedSeconds",
          frameTime != null && tripStart != null ? Math.max(0, frameTime.getEpochSecond() - tripStart.getEpochSecond()) : totalPoints);
      payload.put("insightStats", buildInsightStats());
      payload.put("recommendations", buildRecommendations());
      payload.put("reportReady", totalPoints >= Math.max(1, loader.totalRows()));
      payload.put("rpmAvailable", loader.hasRpm());
      payload.put("kplAvailable", loader.hasKpl());
      return payload;
    } finally {
      lock.unlock();
    }
  }

  private Map<String, Object> buildFallback() {
    Map<String, Object> fallback = new LinkedHashMap<>();
    fallback.put("lat", 18.52);
    fallback.put("lon", 73.85);
    fallback.put("speed", 0);
    fallback.put("rpm", 0);
    fallback.put("kpl", 0);
    fallback.put("status", "UNKNOWN");
    fallback.put("score", round(score));
    fallback.put("insight", "No data available");
    fallback.put("avgSpeed", round(totalPoints == 0 ? 0 : avgSpeedSum / totalPoints));
    fallback.put("avgKpl", round(kplSamples == 0 ? 0 : avgKplSum / kplSamples));
    fallback.put("maxSpeed", round(maxSpeed));
    fallback.put("totalPoints", totalPoints);
    fallback.put("insightStats", buildInsightStats());
    fallback.put("recommendations", buildRecommendations());
    fallback.put("reportReady", totalPoints >= Math.max(1, loader.totalRows()));
    fallback.put("rpmAvailable", loader.hasRpm());
    fallback.put("kplAvailable", loader.hasKpl());
    return fallback;
  }

  public Map<String, Object> generateTripReport() {
    lock.lock();
    try {
      List<Map<String, String>> rows = loader.snapshotRows();
      Map<String, Object> report = new LinkedHashMap<>();
      if (rows.isEmpty()) {
        report.put("reportText", "No dataset loaded.");
        report.put("recommendations", List.of("Load a dataset to generate a trip report."));
        return report;
      }

      ArrayList<Double> speeds = new ArrayList<>();
      ArrayList<Double> kplValues = new ArrayList<>();
      ArrayList<Instant> timestamps = new ArrayList<>();

      double totalDistance = 0;
      double minSpeed = Double.MAX_VALUE;
      double maxSpeedValue = 0;
      double speedSum = 0;
      double minLat = Double.MAX_VALUE;
      double maxLat = -Double.MAX_VALUE;
      double minLon = Double.MAX_VALUE;
      double maxLon = -Double.MAX_VALUE;
      int idlePoints = 0;
      int movingPoints = 0;
      int speedingEvents = 0;
      int lowSpeedCount = 0;
      int mediumSpeedCount = 0;
      int highSpeedCount = 0;
      int reportHardAcceleration = 0;
      int reportHardBraking = 0;

      Double previousLat = null;
      Double previousLon = null;
      double priorSpeed = 0;

      for (Map<String, String> row : rows) {
        double lat = safeParse(row.get(loader.getLatKey()), Double.NaN);
        double lon = safeParse(row.get(loader.getLonKey()), Double.NaN);
        double speed = convertSpeed(row.get(loader.getSpeedKey()));
        double kpl = safeParse(row.get(loader.getKplKey()), 0);

        if (!Double.isNaN(lat) && !Double.isNaN(lon)) {
          minLat = Math.min(minLat, lat);
          maxLat = Math.max(maxLat, lat);
          minLon = Math.min(minLon, lon);
          maxLon = Math.max(maxLon, lon);
          if (previousLat != null && previousLon != null) {
            totalDistance += haversineKm(previousLat, previousLon, lat, lon);
          }
          previousLat = lat;
          previousLon = lon;
        }

        Instant timestamp = parseInstant(row.get(loader.getTimeKey()));
        if (timestamp != null) {
          timestamps.add(timestamp);
        }

        speeds.add(speed);
        speedSum += speed;
        minSpeed = Math.min(minSpeed, speed);
        maxSpeedValue = Math.max(maxSpeedValue, speed);

        if (kpl > 0) {
          kplValues.add(kpl);
        }

        if (speed < 1) {
          idlePoints++;
        } else {
          movingPoints++;
        }

        if (speed > 60) {
          speedingEvents++;
        }
        if (speed <= 20) {
          lowSpeedCount++;
        } else if (speed <= 50) {
          mediumSpeedCount++;
        } else {
          highSpeedCount++;
        }

        double delta = speed - priorSpeed;
        if (delta >= 8) {
          reportHardAcceleration++;
        } else if (delta <= -8) {
          reportHardBraking++;
        }
        priorSpeed = speed;
      }

      ArrayList<Double> sortedSpeeds = new ArrayList<>(speeds);
      sortedSpeeds.sort(Comparator.naturalOrder());
      double avgSpeed = speeds.isEmpty() ? 0 : speedSum / speeds.size();
      double medianSpeed = median(sortedSpeeds);
      double avgKpl = kplValues.isEmpty() ? 0 : kplValues.stream().mapToDouble(Double::doubleValue).average().orElse(0);
      double durationMinutes = computeDurationMinutes(timestamps, rows.size());
      double finalScore = computeTripScore(avgSpeed, avgKpl, idlePoints, reportHardAcceleration, reportHardBraking,
          speedingEvents, rows.size());
      String rating = scoreBand(finalScore);
      List<String> recommendations = buildTripRecommendations(reportHardAcceleration, reportHardBraking, speedingEvents,
          idlePoints, avgKpl, movingPoints);
      String reportTimestamp = formatReportTimestamp(timestamps);

      Map<String, Object> metrics = new LinkedHashMap<>();
      metrics.put("totalDistanceKm", round(totalDistance));
      metrics.put("tripDurationMinutes", round(durationMinutes));
      metrics.put("totalDataPoints", rows.size());
      metrics.put("averageSpeed", round(avgSpeed));
      metrics.put("maximumSpeed", round(maxSpeedValue));
      metrics.put("minimumSpeed", round(minSpeed == Double.MAX_VALUE ? 0 : minSpeed));
      metrics.put("medianSpeed", round(medianSpeed));
      metrics.put("hardBrakingEvents", reportHardBraking);
      metrics.put("hardAccelerationEvents", reportHardAcceleration);
      metrics.put("speedingEvents", speedingEvents);
      metrics.put("idlePoints", idlePoints);
      metrics.put("movingPoints", movingPoints);
      metrics.put("lowSpeedCount", lowSpeedCount);
      metrics.put("mediumSpeedCount", mediumSpeedCount);
      metrics.put("highSpeedCount", highSpeedCount);
      metrics.put("finalScore", round(finalScore));
      metrics.put("rating", rating);
      metrics.put("minLat", round(minLat == Double.MAX_VALUE ? 0 : minLat));
      metrics.put("maxLat", round(maxLat == -Double.MAX_VALUE ? 0 : maxLat));
      metrics.put("minLon", round(minLon == Double.MAX_VALUE ? 0 : minLon));
      metrics.put("maxLon", round(maxLon == -Double.MAX_VALUE ? 0 : maxLon));
      metrics.put("recommendations", recommendations);

      report.putAll(metrics);
      report.put("reportText", buildReportText(reportTimestamp, metrics));
      return report;
    } finally {
      lock.unlock();
    }
  }

  public Map<String, Object> timelineMetadata() {
    lock.lock();
    try {
      Instant start = resolveDatasetStartInstant();
      Instant end = resolveDatasetEndInstant();
      Map<String, Object> metadata = new LinkedHashMap<>();
      metadata.put("rowCount", loader.totalRows());
      metadata.put("timeAvailable", start != null && end != null);
      metadata.put("datasetStartTimestamp", start != null ? start.toEpochMilli() : null);
      metadata.put("datasetEndTimestamp", end != null ? end.toEpochMilli() : null);
      metadata.put("durationSeconds",
          start != null && end != null ? Math.max(0, end.getEpochSecond() - start.getEpochSecond()) : Math.max(0, loader.totalRows() - 1));
      return metadata;
    } finally {
      lock.unlock();
    }
  }

  public Map<String, Object> seekToRow(int rowIndex) {
    lock.lock();
    try {
      reset();
      loader.seekToIndex(0);
      Map<String, Object> payload = buildFallback();
      int safeIndex = Math.max(0, Math.min(rowIndex, Math.max(0, loader.totalRows() - 1)));
      for (int i = 0; i <= safeIndex; i++) {
        payload = nextFrame();
      }
      return payload;
    } finally {
      lock.unlock();
    }
  }

  private void trackInsight(String insight, String status) {
    switch (status) {
      case "GOOD":
        goodStatusCount++;
        break;
      case "NORMAL":
        normalStatusCount++;
        break;
      default:
        poorStatusCount++;
        break;
    }

    switch (insight) {
      case "Smooth driving":
        smoothDrivingCount++;
        break;
      case "Frequent speed changes":
        frequentSpeedChangesCount++;
        break;
      case "Vehicle stopped":
        vehicleStoppedCount++;
        break;
      case "High RPM inefficiency":
        highRpmCount++;
        break;
      default:
        balancedThrottleCount++;
        break;
    }
  }

  private Map<String, Object> buildInsightStats() {
    Map<String, Object> stats = new LinkedHashMap<>();
    stats.put("smoothDriving", smoothDrivingCount);
    stats.put("frequentSpeedChanges", frequentSpeedChangesCount);
    stats.put("vehicleStopped", vehicleStoppedCount);
    stats.put("highRpmInefficiency", highRpmCount);
    stats.put("balancedThrottle", balancedThrottleCount);
    stats.put("goodFrames", goodStatusCount);
    stats.put("normalFrames", normalStatusCount);
    stats.put("poorFrames", poorStatusCount);
    stats.put("hardAcceleration", hardAccelerationCount);
    stats.put("hardBraking", hardBrakingCount);
    return stats;
  }

  private List<String> buildRecommendations() {
    java.util.ArrayList<String> recommendations = new java.util.ArrayList<>();

    if (highRpmCount > Math.max(3, totalPoints / 8)) {
      recommendations.add("High RPM shows up often. Shift earlier or ease throttle during low-speed sections.");
    }
    if (hardBrakingCount > Math.max(3, totalPoints / 10)) {
      recommendations.add("Hard braking is appearing repeatedly. Leave more space ahead and brake earlier.");
    }
    if (hardAccelerationCount > Math.max(3, totalPoints / 10)) {
      recommendations.add("Sudden acceleration is frequent. Smoother throttle application should improve control and mileage.");
    }
    if (frequentSpeedChangesCount > Math.max(4, totalPoints / 7)) {
      recommendations.add("Speed changes are frequent. Smoother acceleration and braking should improve efficiency.");
    }
    if (poorStatusCount > Math.max(5, totalPoints / 3)) {
      recommendations.add("A large part of the trip is classified as poor. Watch for stop-go driving and aggressive throttle inputs.");
    }
    if (vehicleStoppedCount > Math.max(5, totalPoints / 4)) {
      recommendations.add("There is a lot of stationary time. Long idling periods are reducing overall efficiency.");
    }
    if (smoothDrivingCount > Math.max(4, totalPoints / 3)) {
      recommendations.add("Smooth driving appears consistently. Keep that pace to protect mileage.");
    }
    if (recommendations.isEmpty()) {
      recommendations.add("No major efficiency issue stands out yet. Keep replaying more data for a stronger diagnosis.");
    }
    return recommendations;
  }

  private void trackDrivingEvents(double speedDelta) {
    if (speedDelta >= 8) {
      hardAccelerationCount++;
    } else if (speedDelta <= -8) {
      hardBrakingCount++;
    }
  }

  private double computeDurationMinutes(List<Instant> timestamps, int totalRows) {
    if (timestamps.size() >= 2) {
      long seconds = timestamps.get(timestamps.size() - 1).getEpochSecond() - timestamps.get(0).getEpochSecond();
      return Math.max(0, seconds / 60.0);
    }
    return Math.max(0, totalRows - 1) / 60.0;
  }

  private double computeTripScore(double avgSpeed, double avgKpl, int idlePoints, int hardAccelerationEvents,
      int hardBrakingEvents, int speedingEvents, int totalRows) {
    double idleRatio = totalRows == 0 ? 0 : idlePoints / (double) totalRows;
    double reportScore = 68;

    if (avgKpl > 0) {
      reportScore += Math.min(16, avgKpl * 0.75);
      if (avgKpl < 9) {
        reportScore -= 8;
      } else if (avgKpl > 15) {
        reportScore += 4;
      }
    }

    if (avgSpeed >= 12 && avgSpeed <= 55) {
      reportScore += 7;
    } else if (avgSpeed > 0 && avgSpeed < 8) {
      reportScore -= 5;
    }

    reportScore += Math.max(0, 1 - idleRatio) * 8;
    reportScore -= Math.min(12, hardAccelerationEvents * 0.45);
    reportScore -= Math.min(16, hardBrakingEvents * 0.6);
    reportScore -= Math.min(18, speedingEvents * 3.0);
    reportScore -= idleRatio * 10;

    return Math.max(18, Math.min(100, reportScore));
  }

  private String scoreBand(double reportScore) {
    if (reportScore >= 85) {
      return "Excellent";
    }
    if (reportScore >= 72) {
      return "Good";
    }
    if (reportScore >= 60) {
      return "Needs Improvement";
    }
    return "Poor";
  }

  private List<String> buildTripRecommendations(int hardAccelerationEvents, int hardBrakingEvents, int speedingEvents,
      int idlePoints, double avgKpl, int movingPoints) {
    ArrayList<String> recommendations = new ArrayList<>();
    if (hardBrakingEvents > 0) {
      recommendations.add("Try to anticipate traffic and brake more gradually.");
    }
    if (hardAccelerationEvents > 0) {
      recommendations.add("Reduce sudden throttle inputs to improve efficiency and passenger comfort.");
    }
    if (speedingEvents > 0) {
      recommendations.add("Watch highway cruising speed. Speeding is hurting consistency and fuel economy.");
    }
    if (idlePoints > movingPoints / 3) {
      recommendations.add("Long idle periods are noticeable. Reducing stationary engine time should help mileage.");
    }
    if (avgKpl > 0 && avgKpl < 12) {
      recommendations.add("Mileage is below the healthy range. Focus on smoother throttle and lower RPM.");
    }
    if (recommendations.isEmpty()) {
      recommendations.add("Trip behavior is fairly stable. Keep the same smooth inputs for future drives.");
    }
    return recommendations;
  }

  private String buildReportText(String reportTimestamp, Map<String, Object> metrics) {
    int totalPointsValue = (int) metrics.get("totalDataPoints");
    int idlePointsValue = (int) metrics.get("idlePoints");
    int movingPointsValue = (int) metrics.get("movingPoints");
    int lowSpeedCountValue = (int) metrics.get("lowSpeedCount");
    int mediumSpeedCountValue = (int) metrics.get("mediumSpeedCount");
    int highSpeedCountValue = (int) metrics.get("highSpeedCount");
    @SuppressWarnings("unchecked")
    List<String> recommendations = (List<String>) metrics.get("recommendations");

    return String.join("\n",
        "DRIVING REPORT - " + reportTimestamp,
        "================================================================",
        "",
        "TRIP OVERVIEW",
        "-------------",
        "* Total Distance: " + metrics.get("totalDistanceKm") + " km",
        "* Trip Duration: " + metrics.get("tripDurationMinutes") + " minutes",
        "* Total Data Points: " + totalPointsValue,
        "",
        "SPEED ANALYSIS",
        "--------------",
        "* Average Speed: " + metrics.get("averageSpeed") + " km/h",
        "* Maximum Speed: " + metrics.get("maximumSpeed") + " km/h",
        "* Minimum Speed: " + metrics.get("minimumSpeed") + " km/h",
        "* Median Speed: " + metrics.get("medianSpeed") + " km/h",
        "",
        "DRIVING BEHAVIOR",
        "----------------",
        "* Hard Braking Events: " + metrics.get("hardBrakingEvents"),
        "* Hard Acceleration Events: " + metrics.get("hardAccelerationEvents"),
        "* Speeding Events (>60 km/h): " + metrics.get("speedingEvents"),
        "* Time Spent Idle: " + idlePointsValue + " data points",
        "* Time Spent Moving: " + movingPointsValue + " data points",
        "",
        "SPEED DISTRIBUTION",
        "------------------",
        "* Low Speed (0-20 km/h): " + lowSpeedCountValue + " points (" + percentage(lowSpeedCountValue, totalPointsValue) + "%)",
        "* Medium Speed (21-50 km/h): " + mediumSpeedCountValue + " points (" + percentage(mediumSpeedCountValue, totalPointsValue) + "%)",
        "* High Speed (>50 km/h): " + highSpeedCountValue + " points (" + percentage(highSpeedCountValue, totalPointsValue) + "%)",
        "",
        "DRIVING SCORE",
        "-------------",
        "Overall Driving Score: " + metrics.get("finalScore") + "/100 (" + metrics.get("rating") + ")",
        "",
        "RECOMMENDATIONS",
        "---------------",
        recommendations.stream().map(item -> "* " + item).reduce((a, b) -> a + "\n" + b).orElse("* No recommendations"),
        "",
        "Route coordinates saved for mapping purposes.",
        "GPS Data Range: " + metrics.get("minLat") + " to " + metrics.get("maxLat") + " (Lat)",
        "                " + metrics.get("minLon") + " to " + metrics.get("maxLon") + " (Lon)");
  }

  private String percentage(int part, int whole) {
    if (whole <= 0) {
      return "0.0";
    }
    return String.valueOf(round(part * 100.0 / whole));
  }

  private double median(List<Double> values) {
    if (values.isEmpty()) {
      return 0;
    }
    int middle = values.size() / 2;
    if (values.size() % 2 == 0) {
      return (values.get(middle - 1) + values.get(middle)) / 2.0;
    }
    return values.get(middle);
  }

  private Instant parseInstant(String raw) {
    if (raw == null || raw.isBlank()) {
      return null;
    }

    try {
      return ZonedDateTime.parse(raw,
          DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss 'GMT'XXX yyyy", Locale.ENGLISH)).toInstant();
    } catch (DateTimeParseException ignored) {
    }
    try {
      return LocalDateTime.parse(raw,
          DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm:ss.SSS", Locale.ENGLISH))
          .atZone(ZoneId.systemDefault())
          .toInstant();
    } catch (DateTimeParseException ignored) {
    }
    try {
      return LocalDateTime.parse(raw,
          DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH))
          .atZone(ZoneId.systemDefault())
          .toInstant();
    } catch (DateTimeParseException ignored) {
    }
    return null;
  }

  private Instant resolveDatasetStartInstant() {
    List<Map<String, String>> rows = loader.snapshotRows();
    for (Map<String, String> row : rows) {
      Instant parsed = parseInstant(row.get(loader.getTimeKey()));
      if (parsed != null) {
        return parsed;
      }
    }
    return null;
  }

  private Instant resolveDatasetEndInstant() {
    List<Map<String, String>> rows = loader.snapshotRows();
    for (int i = rows.size() - 1; i >= 0; i--) {
      Instant parsed = parseInstant(rows.get(i).get(loader.getTimeKey()));
      if (parsed != null) {
        return parsed;
      }
    }
    return null;
  }

  private String formatReportTimestamp(List<Instant> timestamps) {
    Instant instant = timestamps.isEmpty() ? Instant.now() : timestamps.get(timestamps.size() - 1);
    return DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
        .withZone(ZoneId.systemDefault())
        .format(instant);
  }

  private double haversineKm(double lat1, double lon1, double lat2, double lon2) {
    double earthRadiusKm = 6371.0;
    double dLat = Math.toRadians(lat2 - lat1);
    double dLon = Math.toRadians(lon2 - lon1);
    double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
        + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
        * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return earthRadiusKm * c;
  }

  private double convertSpeed(String raw) {
    double parsed = safeParse(raw, 0);
    if (parsed <= 0) {
      return 0;
    }
    DatasetLoader.SpeedUnit unit = loader.getSpeedUnit();
    if (unit == DatasetLoader.SpeedUnit.MPS) {
      parsed *= 3.6;
    }
    return parsed;
  }

  private String classifyStatus(double speed, double rpm) {
    double variation = Math.abs(speed - previousSpeed);
    boolean highRpm = rpm > 3000;
    if (speed < 1) {
      return "POOR";
    }
    if (variation < 2 && !highRpm) {
      return "GOOD";
    }
    if (variation < 6) {
      return "NORMAL";
    }
    return "POOR";
  }

  private String buildInsight(double speed, double rpm, String status, double variation) {
    if (speed < 1) {
      return "Vehicle stopped";
    }
    if (rpm > 3000 && speed > 5) {
      return "High RPM inefficiency";
    }
    if (variation > 8) {
      return "Frequent speed changes";
    }
    if ("GOOD".equals(status)) {
      return "Smooth driving";
    }
    return "Balanced throttle";
  }

  private void updateScore(String status, double speed, double rpm, double kpl, double fuel, double variation) {
    double frameScore = 74;

    if ("GOOD".equals(status)) {
      frameScore += 14;
    } else if ("NORMAL".equals(status)) {
      frameScore += 3;
    } else {
      frameScore -= 16;
    }

    if (speed < 1) {
      frameScore -= 10;
    } else if (speed >= 15 && speed <= 55) {
      frameScore += 5;
    }

    if (variation > 14) {
      frameScore -= 16;
    } else if (variation > 8) {
      frameScore -= 9;
    } else if (variation < 2.5) {
      frameScore += 6;
    }

    if (rpm > 3600) {
      frameScore -= 14;
    } else if (rpm > 2900) {
      frameScore -= 8;
    } else if (rpm > 0 && rpm <= 2400 && speed > 12) {
      frameScore += 5;
    }

    if (kpl > 20) {
      frameScore += 7;
    } else if (kpl > 14) {
      frameScore += 3;
    } else if (kpl < 9) {
      frameScore -= 10;
    }

    if (fuel > 3.0) {
      frameScore -= 6;
    }

    frameScore = Math.max(8, Math.min(98, frameScore));
    double incrementFactor = totalPoints < 40 ? 0.22 : 0.14;
    score = Math.max(0, Math.min(100, score + (frameScore - score) * incrementFactor));
  }

  private double estimateKpl(double speed, double rpm, double fuel) {
    double base = 13 + Math.max(0, 12 - Math.abs(speed - previousSpeed)) * 0.25;
    if (rpm > 2500) {
      base -= (rpm - 2500) / 1500.0;
    }
    if (fuel > 0) {
      base = Math.max(base, Math.min(45, 16 / (fuel / 10.0 + 0.5)));
    }
    return Math.max(4.5, base);
  }

  private double safeParse(String value, double fallback) {
    if (value == null || value.isBlank()) {
      return fallback;
    }
    try {
      return Double.parseDouble(value.trim());
    } catch (NumberFormatException ex) {
      return fallback;
    }
  }

  private double round(double value) {
    return Math.round(value * 100.0) / 100.0;
  }
}
