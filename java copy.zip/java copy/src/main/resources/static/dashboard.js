const statusColor = {
  GOOD: "#22c55e",
  NORMAL: "#f97316",
  POOR: "#ef4444",
  UNKNOWN: "#64748b",
};

const leafletReady = typeof window.L !== "undefined";
const chartReady = typeof window.Chart !== "undefined";

const map = leafletReady
  ? L.map("map", { zoomControl: false }).setView([18.52, 73.85], 13)
  : null;

if (leafletReady) {
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "",
  }).addTo(map);
}

const heatLayer = leafletReady && typeof L.heatLayer === "function"
  ? L.heatLayer([], { radius: 30, blur: 35 }).addTo(map)
  : { setLatLngs() {} };

const routeLayer = leafletReady
  ? L.layerGroup().addTo(map)
  : { addLayer() {}, removeLayer() {}, clearLayers() {} };

let lastPoint = null;
let lastMarker = null;
const heatPoints = [];

const speedChart = createChart("speedChart", "km/h", "#22c55e");
const rpmChart = createChart("rpmChart", "RPM", "#f97316");
const kplChart = createChart("kplChart", "KPL", "#38bdf8");

let timer;
let running = true;
let speedMultiplier = 1;
let reportGeneratedForRun = false;
let seekInFlight = false;
const baseDelay = 1600;

const startBtn = document.getElementById("startBtn");
const pauseBtn = document.getElementById("pauseBtn");
const reportBtn = document.getElementById("reportBtn");
const statusBadge = document.getElementById("statusBadge");
const loadLocalBtn = document.getElementById("loadLocalBtn");
const backwardBtn = document.getElementById("backwardBtn");
const forwardBtn = document.getElementById("forwardBtn");
const uploadFeedback = document.getElementById("uploadFeedback");
const reportOutput = document.getElementById("reportOutput");
const tripVideo = document.getElementById("tripVideo");
const videoSyncLabel = document.getElementById("videoSyncLabel");
const videoGapInput = document.getElementById("videoGapInput");
const timelineSlider = document.getElementById("timelineSlider");
const timelineLabel = document.getElementById("timelineLabel");

function bindClick(element, handler) {
  if (element) {
    element.addEventListener("click", handler);
  }
}

const mediaState = {
  videoAvailable: false,
  videoSyncOffsetSeconds: 0,
  durationSeconds: 0,
  videos: [],
  activeVideoIndex: -1,
};

const playbackState = {
  rowNumber: 0,
  rowCount: 0,
  elapsedSeconds: 0,
};

if (!leafletReady) {
  document.getElementById("map").innerHTML =
    '<div style="padding:1rem;color:#cbd5e1">Map failed to load, but the analytics panel is still active.</div>';
} else {
  window.addEventListener("load", () => map.invalidateSize());
  window.addEventListener("resize", () => map.invalidateSize());
}

bindClick(startBtn, () => {
  running = true;
  startBtn.classList.add("active");
  pauseBtn.classList.remove("active");
  if (mediaState.videoAvailable && mediaState.activeVideoIndex >= 0) {
    tripVideo.play().catch(() => {});
  }
  scheduleTick();
});

bindClick(pauseBtn, () => {
  running = false;
  pauseBtn.classList.add("active");
  startBtn.classList.remove("active");
  tripVideo.pause();
  clearTimeout(timer);
});

bindClick(reportBtn, () => generateReport(true));
bindClick(loadLocalBtn, loadLocalDataset);
bindClick(backwardBtn, () => jumpFrames(-50));
bindClick(forwardBtn, () => jumpFrames(50));

document.querySelectorAll(".speed-set label").forEach((label) => {
  label.addEventListener("click", () => {
    speedMultiplier = Number(label.dataset.speed);
    document.querySelectorAll(".speed-set label").forEach((node) => {
      node.classList.toggle("active", node === label);
    });
  });
});

if (timelineSlider && timelineLabel) {
  timelineSlider.addEventListener("input", () => {
    timelineLabel.textContent = `Frame ${Number(timelineSlider.value) + 1} / ${playbackState.rowCount}`;
  });

  timelineSlider.addEventListener("change", () => {
    seekToRow(Number(timelineSlider.value));
  });
}

if (videoGapInput) {
  videoGapInput.addEventListener("input", () => {
    syncTripVideo(playbackState.elapsedSeconds);
    updateVideoSyncLabel();
  });
}

if (tripVideo) {
  tripVideo.addEventListener("loadedmetadata", () => {
    const activeVideo = mediaState.videos[mediaState.activeVideoIndex];
    if (activeVideo) {
      activeVideo.duration = tripVideo.duration;
    }
    updateVideoSyncLabel();
    syncTripVideo(playbackState.elapsedSeconds);
  });

  tripVideo.addEventListener("error", () => {
    const activeVideo = mediaState.videos[mediaState.activeVideoIndex];
    videoSyncLabel.textContent = activeVideo
      ? `${activeVideo.fileName} failed to play in this browser`
      : "Video failed to play in this browser";
  });
}

async function loadLocalDataset() {
  uploadFeedback.textContent = "Loading local dataset...";
  uploadFeedback.style.color = "#f97316";
  try {
    const response = await fetch("/api/reload-local", { method: "POST" });
    const result = await response.json();
    if (!response.ok) {
      uploadFeedback.textContent = result.message || "Reload failed";
      uploadFeedback.style.color = "#ef4444";
      return;
    }
    uploadFeedback.textContent = result.message;
    uploadFeedback.style.color = "#22c55e";
    resetVisualization();
    reportGeneratedForRun = false;
    await loadMediaMetadata();
    running = true;
    startBtn.classList.add("active");
    pauseBtn.classList.remove("active");
    scheduleTick();
    setTimeout(() => {
      uploadFeedback.textContent = "";
    }, 3000);
  } catch (error) {
    uploadFeedback.textContent = "Failed to load local dataset";
    uploadFeedback.style.color = "#ef4444";
  }
}

function scheduleTick() {
  clearTimeout(timer);
  if (!running) {
    return;
  }
  timer = setTimeout(async () => {
    await pollFrame();
    scheduleTick();
  }, baseDelay / speedMultiplier);
}

async function pollFrame() {
  try {
    const response = await fetch("/api/simulate");
    if (!response.ok) {
      throw new Error("Simulation failed");
    }
    const payload = await response.json();
    updateDashboard(payload);
    if (payload.reportReady && !reportGeneratedForRun) {
      generateReport(false);
    }
  } catch (error) {
    statusBadge.textContent = "OFFLINE";
    statusBadge.style.background = "#7f1d1d";
    uploadFeedback.textContent = "Backend not reachable";
    uploadFeedback.style.color = "#ef4444";
  }
}

function updateDashboard(data) {
  const {
    lat,
    lon,
    speed,
    rpm,
    kpl,
    status,
    insight,
    score,
    avgSpeed,
    avgKpl,
    maxSpeed,
    totalPoints,
    rowNumber,
    rowCount,
    insightStats,
    recommendations,
    elapsedSeconds,
    rpmAvailable,
    kplAvailable,
  } = data;

  playbackState.rowNumber = Number(rowNumber || 0);
  playbackState.rowCount = Number(rowCount || 0);
  playbackState.elapsedSeconds = Number(elapsedSeconds || 0);
  updateTimelineUi();

  statusBadge.textContent = status;
  statusBadge.style.background = statusColor[status] || "#475569";
  statusBadge.style.color = "#f8fafc";

  document.getElementById("speedValue").textContent = Number(speed || 0).toFixed(1);
  document.getElementById("rpmValue").textContent = rpmAvailable ? Number(rpm || 0).toFixed(0) : "--";
  document.getElementById("kplValue").textContent = Number(kpl || 0).toFixed(1);
  document.getElementById("scoreValue").textContent = Number(score || 0).toFixed(1);
  document.getElementById("insightValue").textContent = insight || "No insight available";
  document.getElementById("avgSpeedValue").textContent = Number(avgSpeed || 0).toFixed(1);
  document.getElementById("avgKplValue").textContent =
    kplAvailable || avgKpl > 0 ? Number(avgKpl || 0).toFixed(1) : "--";
  document.getElementById("maxSpeedValue").textContent = Number(maxSpeed || 0).toFixed(1);
  document.getElementById("totalPointsValue").textContent = Number(totalPoints || 0);

  updateInsightCounts(insightStats || {});
  updateRecommendations(recommendations || []);
  syncTripVideo(playbackState.elapsedSeconds);

  pushChart(speedChart, Number(speed || 0));
  pushChart(kplChart, Number(kpl || 0));
  if (rpmAvailable) {
    pushChart(rpmChart, Number(rpm || 0));
    document.getElementById("rpmChartContainer").style.display = "";
  } else {
    document.getElementById("rpmChartContainer").style.display = "none";
  }

  if (leafletReady && Number.isFinite(lat) && Number.isFinite(lon)) {
    const point = [lat, lon];
    map.panTo(point);
    const segmentColor = statusColor[status] || "#475569";
    if (lastPoint) {
      routeLayer.addLayer(L.polyline([lastPoint, point], {
        color: segmentColor,
        weight: 5,
        opacity: 0.7,
      }));
    }
    lastPoint = point;
    if (lastMarker) {
      routeLayer.removeLayer(lastMarker);
    }
    lastMarker = L.circleMarker(point, {
      radius: 6,
      color: segmentColor,
      fillColor: segmentColor,
      fillOpacity: 0.9,
      weight: 1,
    }).addTo(routeLayer);
    heatPoints.push([...point, 0.5]);
    if (heatPoints.length > 90) {
      heatPoints.shift();
    }
    heatLayer.setLatLngs(heatPoints);
    map.invalidateSize();
  }
}

function resetVisualization() {
  routeLayer.clearLayers();
  heatPoints.length = 0;
  heatLayer.setLatLngs([]);
  lastPoint = null;
  lastMarker = null;
  resetChart(speedChart);
  resetChart(rpmChart);
  resetChart(kplChart);
  updateInsightCounts({});
  updateRecommendations([]);
  reportOutput.textContent = "Generate a report after or during playback to see the full trip summary.";
  reportGeneratedForRun = false;
  playbackState.rowNumber = 0;
  playbackState.rowCount = 0;
  playbackState.elapsedSeconds = 0;
  updateTimelineUi();
}

async function loadMediaMetadata() {
  try {
    const response = await fetch("/api/media");
    const payload = await response.json();
    mediaState.videoAvailable = Boolean(payload.videoAvailable);
    mediaState.videoSyncOffsetSeconds = Number(payload.videoSyncOffsetSeconds || 0);
    mediaState.durationSeconds = Number(payload.durationSeconds || 0);
    mediaState.videos = (payload.videos || []).map((video) => ({
      ...video,
      duration: 0,
    }));
    mediaState.activeVideoIndex = -1;

    if (mediaState.videoAvailable && mediaState.videos.length) {
      setActiveVideo(0);
    } else {
      tripVideo.removeAttribute("src");
      tripVideo.load();
      videoSyncLabel.textContent = "Add video1.mov / video2.mov to /video";
    }
  } catch (error) {
    mediaState.videoAvailable = false;
    videoSyncLabel.textContent = "Video metadata unavailable";
  }
}

function setActiveVideo(index) {
  if (!mediaState.videos.length) {
    return;
  }
  const safeIndex = Math.max(0, Math.min(index, mediaState.videos.length - 1));
  if (mediaState.activeVideoIndex === safeIndex) {
    return;
  }
  mediaState.activeVideoIndex = safeIndex;
  const selected = mediaState.videos[safeIndex];
  if (tripVideo.getAttribute("src") !== selected.url) {
    tripVideo.src = selected.url;
    tripVideo.load();
  }
  updateVideoSyncLabel();
}

function syncTripVideo(elapsedSeconds) {
  if (!mediaState.videoAvailable || !Number.isFinite(Number(elapsedSeconds)) || !mediaState.videos.length) {
    return;
  }

  const currentElapsed = Number(elapsedSeconds);
  const gapSeconds = Number(videoGapInput.value || 0);
  const firstDuration = Number(mediaState.videos[0]?.duration || 0);

  if (mediaState.videos.length > 1 && firstDuration > 0) {
    const secondStart = firstDuration + gapSeconds;
    if (currentElapsed >= secondStart) {
      setActiveVideo(1);
      seekVideoTime(currentElapsed - secondStart);
      return;
    }
    if (currentElapsed > firstDuration && currentElapsed < secondStart) {
      tripVideo.pause();
      videoSyncLabel.textContent = `Gap window (${gapSeconds}s)`;
      return;
    }
  }

  setActiveVideo(0);
  seekVideoTime(currentElapsed + mediaState.videoSyncOffsetSeconds);
}

function seekVideoTime(targetTime) {
  const safeTime = Math.max(0, targetTime);
  if (Math.abs(tripVideo.currentTime - safeTime) > 0.8) {
    tripVideo.currentTime = safeTime;
  }
  if (running && tripVideo.paused) {
    tripVideo.play().catch(() => {});
  }
}

function updateVideoSyncLabel() {
  if (!mediaState.videoAvailable || mediaState.activeVideoIndex < 0) {
    return;
  }
  const active = mediaState.videos[mediaState.activeVideoIndex];
  const gap = Number(videoGapInput.value || 0);
  videoSyncLabel.textContent = mediaState.videos.length > 1
    ? `${active.fileName} | gap ${gap}s`
    : `${active.fileName} | synced`;
}

function updateTimelineUi() {
  timelineSlider.max = String(Math.max(0, playbackState.rowCount - 1));
  timelineSlider.value = String(Math.max(0, playbackState.rowNumber - 1));
  timelineLabel.textContent = `Frame ${playbackState.rowNumber} / ${playbackState.rowCount}`;
}

function jumpFrames(delta) {
  if (!playbackState.rowCount) {
    return;
  }
  const currentRow = Math.max(0, playbackState.rowNumber - 1);
  const targetRow = clamp(currentRow + delta, 0, playbackState.rowCount - 1);
  seekToRow(targetRow);
}

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

async function seekToRow(row) {
  if (seekInFlight) {
    return;
  }
  seekInFlight = true;
  const wasRunning = running;
  clearTimeout(timer);
  running = false;
  tripVideo.pause();
  try {
    const response = await fetch(`/api/seek?row=${Math.max(0, row)}`);
    if (!response.ok) {
      throw new Error("Seek failed");
    }
    const payload = await response.json();
    updateDashboard(payload);
    running = wasRunning;
    if (running) {
      startBtn.classList.add("active");
      pauseBtn.classList.remove("active");
      scheduleTick();
    } else {
      pauseBtn.classList.add("active");
      startBtn.classList.remove("active");
    }
  } catch (error) {
    uploadFeedback.textContent = "Seek failed";
    uploadFeedback.style.color = "#ef4444";
    running = wasRunning;
    if (running) {
      scheduleTick();
    }
  } finally {
    seekInFlight = false;
  }
}

function updateInsightCounts(stats) {
  document.getElementById("smoothCount").textContent = Number(stats.smoothDriving || 0);
  document.getElementById("throttleCount").textContent = Number(stats.balancedThrottle || 0);
  document.getElementById("rpmHighCount").textContent = Number(stats.highRpmInefficiency || 0);
  document.getElementById("hardAccelCount").textContent = Number(stats.hardAcceleration || 0);
  document.getElementById("hardBrakeCount").textContent = Number(stats.hardBraking || 0);
  document.getElementById("speedChangeCount").textContent = Number(stats.frequentSpeedChanges || 0);
  document.getElementById("stoppedCount").textContent = Number(stats.vehicleStopped || 0);
  document.getElementById("poorFrameCount").textContent = Number(stats.poorFrames || 0);
}

function updateRecommendations(items) {
  const container = document.getElementById("recommendationList");
  container.innerHTML = "";
  const safeItems = items.length
    ? items
    : ["Replay the trip to generate driving recommendations."];

  safeItems.forEach((item) => {
    const node = document.createElement("div");
    node.className = "recommendation-item";
    node.textContent = item;
    container.appendChild(node);
  });
}

async function generateReport(showStatus = true) {
  if (showStatus) {
    uploadFeedback.textContent = "Generating report...";
    uploadFeedback.style.color = "#f97316";
  }
  try {
    const response = await fetch("/api/report");
    const payload = await response.json();
    if (!response.ok) {
      throw new Error(payload.message || "Report generation failed");
    }
    reportOutput.textContent = payload.reportText || "No report available.";
    reportGeneratedForRun = true;
    if (showStatus) {
      uploadFeedback.textContent = "Driving report ready";
      uploadFeedback.style.color = "#22c55e";
    }
  } catch (error) {
    if (showStatus) {
      uploadFeedback.textContent = "Failed to generate report";
      uploadFeedback.style.color = "#ef4444";
    }
  }
}

function createChart(id, label, color) {
  if (!chartReady) {
    return {
      data: { labels: [], datasets: [{ data: [] }] },
      update() {},
    };
  }

  const ctx = document.getElementById(id);
  return new Chart(ctx, {
    type: "line",
    data: {
      labels: [],
      datasets: [
        {
          label,
          data: [],
          borderColor: color,
          backgroundColor: "rgba(255,255,255,0.05)",
          borderWidth: 2.5,
          pointRadius: 0,
          tension: 0.3,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: {
          display: false,
        },
        y: {
          grid: {
            color: "rgba(148, 163, 184, 0.2)",
          },
        },
      },
      plugins: {
        legend: {
          display: false,
        },
      },
    },
  });
}

function pushChart(chart, value) {
  const dataset = chart.data.datasets[0];
  dataset.data.push(value);
  chart.data.labels.push(new Date().toLocaleTimeString());
  if (dataset.data.length > 40) {
    dataset.data.shift();
    chart.data.labels.shift();
  }
  chart.update("none");
}

function resetChart(chart) {
  chart.data.labels = [];
  chart.data.datasets[0].data = [];
  chart.update("none");
}

scheduleTick();
loadMediaMetadata();
