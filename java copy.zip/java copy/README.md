# GeoDriveAI

GeoDriveAI is a lightweight Spring Boot + single-page dashboard experience for replaying vehicle telemetry, highlighting inefficiencies, and surfacing driver insights in real time. The backend dynamically adapts to any uploadable CSV so long as it contains at least latitude/longitude and some indication of speed. Missing columns (RPM, fuel, mileage) are handled gracefully via estimations so the UI never shows `undefined`.

## Structure

- `pom.xml` – Maven Spring Boot project definition.
- `src/main/java/com/geodriveai` – Application entry point, CSV loader, simulation logic, REST controller.
- `src/main/resources/static` – Dark dashboard assets (Leaflet + Chart.js).
- `src/main/resources/dataset.csv` – Starter telemetry sample that is copied into `dataset.csv` at runtime.

## Running

1. Ensure Java 17+ and Maven are installed.
2. Run `mvn spring-boot:run`.
3. Open http://localhost:8080/ in your browser. The dashboard pulls `/api/simulate` for live playback and shows a “Load Local Dataset” button that loads the newest CSV from `video/` when available, otherwise `src/main/resources/dataset.csv`.

## Backend

- `DatasetLoader` inspects any CSV header row for keywords like `latitude`, `longitude`, `speed`, `rpm`, `fuel`, and `kpl`. It supports comma or tab delimiters and loops the dataset for continuous replay.
- `SimulationService` consumes rows, converts speeds (m/s → km/h), estimates missing mileage or fuel, classifies driving status (GOOD / NORMAL / POOR), maintains rolling analytics (avg speed, avg mileage, max speed, total points), and protects the score between 0–100.
- `/api/simulate` returns an object with `{lat, lon, speed, rpm, kpl, status, score, insight, avgSpeed, avgKpl, maxSpeed, totalPoints}`.
- `/api/upload` accepts a CSV file and reloads the simulation data mid-flight.

## Frontend

- The UI uses a split layout: map/heatmap on the left (Leaflet + `leaflet.heat`), and stats + analytics on the right.
- Controls allow uploading a new dataset, starting/pausing the stream, and adjusting playback speed (1×, 2×, 5×, 10×).
- Analytics cards show live RPM, speed, KPL, driver insight, total points, average speed / mileage, and max speed.
- Animated charts (Chart.js) show speed, RPM, and KPL trends. Charts gracefully hide RPM when no RPM column exists.

## Video Sync

1. Put a trip CSV and its matching video files inside the project `video/` folder.
2. Supported video formats are `.mp4`, `.mov`, `.m4v`, and `.webm`.
3. If you have two recordings, name them in order such as `video1.mov` and `video2.mov`. The dashboard will switch between them automatically.
4. Use the `Video Gap` control in the dashboard to enter the missing time between the clips, for example `18` seconds.
5. The playback timeline slider and `-10s` / `+10s` buttons let you scrub the simulation and the video together.

## Loading the bundled dataset

1. Click “Load Local Dataset” in the dashboard to reload `src/main/resources/dataset.csv`.
2. The controller calls `/api/reload-local`, resets the simulation, and the UI reloads the newest local dataset source.

## Notes

- The sample dataset is copied from `src/main/resources/dataset.csv` into the working directory on the first run so uploads don’t accidentally overwrite your sample.
- Frontend assets live under `src/main/resources/static`, allowing you to extend the map, add widgets, or swap chart libraries without touching the backend.
