# Java OOPS Assignments

This project contains Java programs demonstrating Object-Oriented Programming concepts.

## Assignment 1
- Student class
- Demonstrates class, object, constructor, and methods

## Assignment 2
- Demonstrates hierarchical inheritance
- Base class: Employee
- Derived classes: FullTimeEmployee and InternEmployee
- Salary calculation with different hikes

## Concepts Used
- Classes and Objects
- Constructors
- Methods
- Inheritance
