class Student {
    int rollNo;
    String name;
    int age;

    Student(int r, String n, int a) {
        rollNo = r;
        name = n;
        age = a;
    }

    void display() {
        System.out.println("Roll No: " + rollNo);
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }
}

public class Assignment1_Student {
    public static void main(String[] args) {
        Student s1 = new Student(1, "Juhi", 20);
        Student s2 = new Student(2, "Aman", 21);

        s1.display();
        System.out.println();
        s2.display();
    }
}
