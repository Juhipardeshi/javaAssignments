class Employee {
    double salary;

    Employee(double salary) {
        this.salary = salary;
    }

    void displaySalary(String message) {
        System.out.println(message + ": " + salary);
    }
}

class FullTimeEmployee extends Employee {
    FullTimeEmployee(double salary) {
        super(salary);
    }

    void calculateSalary() {
        salary = salary + (salary * 0.50);
    }
}

class InternEmployee extends Employee {
    InternEmployee(double salary) {
        super(salary);
    }

    void calculateSalary() {
        salary = salary + (salary * 0.25);
    }
}

public class Assignment2_Inheritance {
    public static void main(String[] args) {

        FullTimeEmployee fte = new FullTimeEmployee(40000);
        InternEmployee intern = new InternEmployee(20000);

        System.out.println("Full Time Employee");
        fte.displaySalary("Salary before hike");
        fte.calculateSalary();
        fte.displaySalary("Salary after hike");

        System.out.println();

        System.out.println("Intern Employee");
        intern.displaySalary("Salary before hike");
        intern.calculateSalary();
        intern.displaySalary("Salary after hike");
    }
}
