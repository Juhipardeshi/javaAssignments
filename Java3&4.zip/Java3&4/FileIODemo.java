import java.io.*;

public class FileIODemo {
    public static void main(String[] args) {

        String fileName = "sample.txt";

        // Writing to a file using try-with-resources
        try (FileWriter writer = new FileWriter(fileName)) {
            writer.write("Hello, this is a File I/O example in Java.\n");
            writer.write("We are learning exception handling.\n");
            System.out.println("Data written successfully.");
        } 
        catch (IOException e) {
            System.out.println("Error while writing to file: " + e.getMessage());
        }

        // Reading from a file using try-catch-finally
        FileReader reader = null;
        BufferedReader br = null;

        try {
            reader = new FileReader(fileName);
            br = new BufferedReader(reader);

            String line;
            System.out.println("\nReading file content:");
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }
        } 
        catch (FileNotFoundException e) {
            System.out.println("File not found: " + e.getMessage());
        } 
        catch (IOException e) {
            System.out.println("Error while reading file: " + e.getMessage());
        } 
        finally {
            // Closing resources manually
            try {
                if (br != null)
                    br.close();
                if (reader != null)
                    reader.close();
            } 
            catch (IOException e) {
                System.out.println("Error closing file: " + e.getMessage());
            }
        }

        System.out.println("\nProgram executed successfully.");
    }
}